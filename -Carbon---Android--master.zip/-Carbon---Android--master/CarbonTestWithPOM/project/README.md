#### **Carbon Android App Automation Implementation**

I used the Page Object Model framework with different tabs; the Locators, Pages, and the Tests
with the unittest python testing framework\
Steps to run: run on the terminal:`
pip install Appium-Python-Client\
To run the test simply run the: **_project/Tests/mainTest.py_** file in the Tests folder
with **_python -m unittest mainTest.py_**

